package com.akash.reelcounter

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class ReelService : AccessibilityService() {
    private var lastCount = 0L

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        if (e.eventType != AccessibilityEvent.TYPE_VIEW_SCROLLED) return
        val now = System.currentTimeMillis()
        if (now - lastCount < 900) return          // one swipe fires many events
        val root = rootInActiveWindow ?: return
        if (inReels(root, 0)) { lastCount = now; Store.increment(this) }
    }

    // Reels screen has view ids containing "clips" (heuristic; Instagram may change this)
    private fun inReels(n: AccessibilityNodeInfo?, depth: Int): Boolean {
        if (n == null || depth > 8) return false
        val id = n.viewIdResourceName ?: ""
        if (id.contains("clips_viewer") || id.contains("clips_video")) return true
        for (i in 0 until n.childCount) if (inReels(n.getChild(i), depth + 1)) return true
        return false
    }

    override fun onInterrupt() {}
}
