package com.akash.reelcounter

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private lateinit var count: TextView
    private lateinit var history: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(48, 120, 48, 48) }
        l.addView(TextView(this).apply { text = "Reels watched today"; textSize = 18f; gravity = Gravity.CENTER })
        count = TextView(this).apply { textSize = 96f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER }
        l.addView(count)
        l.addView(Button(this).apply {
            text = "Enable tracking (Accessibility)"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        history = TextView(this).apply { textSize = 16f; setPadding(0, 64, 0, 0) }
        l.addView(history)
        setContentView(ScrollView(this).apply { addView(l) })
    }

    override fun onResume() {
        super.onResume()
        count.text = Store.today(this).toString()
        history.text = "Last 7 days\n\n" + Store.lastDays(this, 7).joinToString("\n") { "${it.first}   →   ${it.second}" }
    }
}
