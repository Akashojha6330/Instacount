package com.akash.reelcounter

import android.content.Context
import java.text.SimpleDateFormat
import java.util.*

object Store {
    private fun prefs(c: Context) = c.getSharedPreferences("reels", Context.MODE_PRIVATE)
    private fun key(d: Date = Date()) = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(d)
    fun increment(c: Context) { val p = prefs(c); val k = key(); p.edit().putInt(k, p.getInt(k, 0) + 1).apply() }
    fun today(c: Context) = prefs(c).getInt(key(), 0)
    fun lastDays(c: Context, n: Int): List<Pair<String, Int>> {
        val cal = Calendar.getInstance()
        return (0 until n).map { val k = key(cal.time); cal.add(Calendar.DAY_OF_YEAR, -1); k to prefs(c).getInt(k, 0) }
    }
}
